package com.java.oopDesign;

public class AppTest {
	
	public static void main(String[] args) {
		
		Program p1 = new Program(1,"p1");
		Program p2 = new Program(2,"p2");
		Program p3 = new Program(3,"p3");
		
		
		
	}
}
